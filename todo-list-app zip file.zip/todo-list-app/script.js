window.onload = function () {
    displayTasks("all");
};

// Add task
function addTask() {
    let input = document.getElementById("taskInput");
    let text = input.value.trim();

    if (text === "") {
        alert("Please enter a task");
        return;
    }

    let now = new Date();
    let time = now.toLocaleString("en-IN", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    });

    let tasks = getTasks();
    tasks.push({
        text: text,
        completed: false,
        time: time
    });

    localStorage.setItem("tasks", JSON.stringify(tasks));
    input.value = "";
    displayTasks("all");
}

// Display tasks
function displayTasks(filter) {
    let taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

    let tasks = getTasks();

    tasks.forEach((task, index) => {
        if (
            filter === "completed" && !task.completed ||
            filter === "pending" && task.completed
        ) return;

        let li = document.createElement("li");
        if (task.completed) li.classList.add("completed");

        li.innerHTML = `
            <div>
                <span onclick="toggleTask(${index})">${task.text}</span>
                <div class="time">Added on: ${task.time}</div>
            </div>
            <span onclick="deleteTask(${index})">❌</span>
        `;

        taskList.appendChild(li);
    });
}

// Toggle task
function toggleTask(index) {
    let tasks = getTasks();
    tasks[index].completed = !tasks[index].completed;
    localStorage.setItem("tasks", JSON.stringify(tasks));
    displayTasks("all");
}

// Delete task
function deleteTask(index) {
    let tasks = getTasks();
    tasks.splice(index, 1);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    displayTasks("all");
}

// Filter
function filterTasks(type) {
    displayTasks(type);
}

// Get from storage
function getTasks() {
    let tasks = localStorage.getItem("tasks");
    return tasks ? JSON.parse(tasks) : [];
}